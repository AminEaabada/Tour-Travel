// import React from 'react';
// import Header from './Header';
// import Footer from './Footer';
// import { Link } from 'react-router-dom';

// function PlaceDetails({ placeId }) {
//   // fetch the details for the selected place using the placeId prop
//   // render the details on the page
//   return (
//     <>
//     <Header />
//     <section class="PlaceDetails" id="PlaceDetails">

//         <h1 class="heading">
//            <span> More Information About Isla Mujeres </span>
//         </h1>

//         <div class="box-container">
//             <div className="box">
//                 <img src="images/-travel-.jpg" alt=""/>
//                 <div className="content">
//                     <h3>Isla Mujeres</h3>
//                     <p>Most Beautiful Islands in Mexico.</p>
//                     <Link to='/Gallery' className="btn">Go Back</Link>
//                 </div>
//             </div>
//         </div>
//         </section>
//         </>
//   );
// }

// export default PlaceDetails;




import { Link, useParams } from "react-router-dom";
import React from "react";
import axios from "axios";
import { useEffect, useState } from "react";
import Header from "./Header";
import '../popup.css';
const PlaceDetails = ({ place }) => {
  const id = useParams()

  const [places, setPlaces] = useState([]);


  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await axios.get(`http://localhost:5000/places/${id.id}`)
        setPlaces(data.data)
      }
      catch (error) {
        console.log(error);
      }
    }
    fetchData()
  }, [])






  return (
    <>
      <Header />

      <section className="PlaceDetails" id="PlaceDetails">
        <div className="box-container">
        <h1 className="heading">
                <span>P</span>
                <span>l</span>
                <span>a</span>
                <span>c</span>
                <span>e</span>
                <span class="space"></span>
                <span>D</span>
                <span>e</span>
                <span>t</span>
                <span>a</span>
                <span>i</span>
                <span>l</span>
                <span>s</span>
            </h1>
          <div className="box">
              <img src="/images/greekIsland.jpg" alt={places.title} />
              <img src="/images/R-1.jpg" alt={places.title} />
              <img src="/images/R.jpg" alt={places.title} />
            <div className="content">
              <h2>{places.title}</h2>
              <p>{places.description}</p>
              <button>
                <Link to="/Gallery" className="btn">Go Back</Link>
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default PlaceDetails;


